package peli;
// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   KeyCodeBundle_fi_FI.java

import java.util.ListResourceBundle;

public class KeyCodeBundle_fi_FI extends ListResourceBundle
{

    public KeyCodeBundle_fi_FI()
    {
    }

    public Object[][] getContents()
    {
        return contents;
    }

    private Object contents[][] = {
        {
            "oldMnemonic", new Integer(86)
        }, {
            "newMnemonic", new Integer(85)
        }, {
            "quitMnemonic", new Integer(76)
        }, {
            "saveMnemonic", new Integer(84)
        }, {
            "mHtmlMnemonic", new Integer(79)
        }, {
            "sHtmlMnemonic", new Integer(83)
        }, {
            "htmlMnemonic", new Integer(72)
        }
    };
}
