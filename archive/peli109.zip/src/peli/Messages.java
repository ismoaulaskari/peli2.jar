package peli;
// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   Messages.java

/** 
 * why not put this in a properties-file?
 * 
 */
public class Messages
{

    public Messages()
    {
    }

    public static final String mainWindowHeader = "Turnaus";
    public static final String oldButton = "(V)";
    public static final char oldMnemonic = 86;
    public static final String oldToolTip = "Avaa vanha turnaus...";
    public static final String newButton = "(U)";
    public static final char newMnemonic = 85;
    public static final String newToolTip = "Aloita uusi turnaus...";
    public static final String restartButton = "(F)";
    public static final char restartMnemonic = 76;
    public static final String restartToolTip = "N\344yt\344 lopputulokset";
    public static final String quitButton = "(L)";
    public static final char quitMnemonic = 76;
    public static final String quitToolTip = "Lopeta ohjelma";
    public static final String saveButton = "(T)";
    public static final char saveMnemonic = 84;
    public static final String saveToolTip = "Talleta t\344m\344n turnauksen tilanne";
    public static final String mHtmlButton = "(O)";
    public static final char mHtmlMnemonic = 79;
    public static final String mHtmlToolTip = "Talleta otteluohjelma html-tiedostoksi";
    public static final String sHtmlButton = "(S)";
    public static final char sHtmlMnemonic = 83;
    public static final String sHtmlToolTip = "Talleta sarjataulukko html-tiedostoksi";
    public static final String htmlButton = "(H)";
    public static final char htmlMnemonic = 72;
    public static final String htmlToolTip = "Luo turnauksen www-sivu";
    public static final String newFileQuestion = "Uuden turnaustiedoston nimi?";
    public static final String playerNameFileQuestion = "Pelaajaluettelotiedoston nimi?";
    public static final String newFileOpenButton = "Avaa";
    public static final String divisionSelectorHeader = " Valitse lohko: ";
    public static final String divisionCardHeader = " Valittu lohko ";
    public static final String fileMenuHeader = "Turnaus";
    public static final String newItemText = "Uusi...";
    public static final String oldItemText = "Avaa...";
    public static final String oldItemTip = "Avaa aiemmin talletettu turnaus";
    public static final String quitItemText = "Lopeta";
    public static final String quitItemTip = "Lopeta ohjelma";
}
