Aja ohjelmat komennolla 
java -jar LauncherFD.jar launcher.properties

Tarvittaessa säädä ensin konekohtaiset asetukset properties-tiedostoista.
